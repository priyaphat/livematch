import React, { useState } from 'react';
import { usePos } from '../context/PosContext';
import { StoreSettings } from '../types';
import {
  Settings,
  Store,
  Printer,
  DollarSign,
  Database,
  Save,
  Volume2,
  CheckCircle2,
  RefreshCw,
  Download,
  Sliders,
} from 'lucide-react';
import {
  INITIAL_SETTINGS,
  INITIAL_PRODUCTS,
  INITIAL_SUPPLIERS,
  INITIAL_HELD_ORDERS,
  INITIAL_ORDERS,
  INITIAL_STOCK_MOVEMENTS,
} from '../data/mockData';

export const SettingsView: React.FC = () => {
  const { settings, updateSettings, showToast, playBeep } = usePos();
  const [activeTab, setActiveTab] = useState<'store' | 'printer' | 'tax' | 'data'>('store');
  const [formData, setFormData] = useState<StoreSettings>({ ...settings });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(formData);
    playBeep('success');
  };

  const handleResetData = () => {
    if (
      window.confirm(
        'คุณแน่ใจหรือไม่ว่าต้องการรีเซ็ตข้อมูลตัวอย่างกลับเป็นค่าเริ่มต้น? (ข้อมูลที่แก้ไขจะถูกล้าง)'
      )
    ) {
      localStorage.setItem('siampure_settings', JSON.stringify(INITIAL_SETTINGS));
      localStorage.setItem('siampure_products', JSON.stringify(INITIAL_PRODUCTS));
      localStorage.setItem('siampure_suppliers', JSON.stringify(INITIAL_SUPPLIERS));
      localStorage.setItem('siampure_held_orders', JSON.stringify(INITIAL_HELD_ORDERS));
      localStorage.setItem('siampure_orders', JSON.stringify(INITIAL_ORDERS));
      localStorage.setItem('siampure_stock_movements', JSON.stringify(INITIAL_STOCK_MOVEMENTS));
      localStorage.removeItem('siampure_cart');
      window.location.reload();
    }
  };

  const handleExportBackup = () => {
    const backup = {
      settings,
      products: localStorage.getItem('siampure_products'),
      orders: localStorage.getItem('siampure_orders'),
      held_orders: localStorage.getItem('siampure_held_orders'),
      stock_movements: localStorage.getItem('siampure_stock_movements'),
      suppliers: localStorage.getItem('siampure_suppliers'),
      exportDate: new Date().toISOString(),
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backup, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `siampure-pos-backup-${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('ดาวน์โหลดไฟล์สำรองข้อมูล JSON เรียบร้อยแล้ว', 'success');
  };

  return (
    <div className="flex-1 w-full p-4 sm:p-6 space-y-6 pb-24 overflow-y-auto bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
            <Settings className="w-6 h-6 text-emerald-500" />
            <span>ตั้งค่าระบบ Siam Pure POS</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            กำหนดข้อมูลร้านค้า อุปกรณ์เครื่องพิมพ์ อัตราภาษี และจุดทศนิยม
          </p>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex bg-white dark:bg-slate-900 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs overflow-x-auto gap-1 shadow-xs">
        <button
          onClick={() => setActiveTab('store')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold whitespace-nowrap transition-all ${
            activeTab === 'store'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Store className="w-4 h-4" />
          <span>ข้อมูลร้านค้า (Store Info)</span>
        </button>

        <button
          onClick={() => setActiveTab('printer')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold whitespace-nowrap transition-all ${
            activeTab === 'printer'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Printer className="w-4 h-4" />
          <span>เครื่องพิมพ์ & ใบเสร็จ</span>
        </button>

        <button
          onClick={() => setActiveTab('tax')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold whitespace-nowrap transition-all ${
            activeTab === 'tax'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>ภาษี & การเงิน (VAT / Decimal)</span>
        </button>

        <button
          onClick={() => setActiveTab('data')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold whitespace-nowrap transition-all ${
            activeTab === 'data'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>สำรองข้อมูล & รีเซ็ต</span>
        </button>
      </div>

      {/* TAB CONTENTS */}
      <form onSubmit={handleSave} className="space-y-6">
        {/* TAB 1: STORE INFO */}
        {activeTab === 'store' && (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-md space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-800 pb-3 flex items-center gap-2">
              <Store className="w-4 h-4 text-emerald-500" />
              <span>ข้อมูลประจำร้านค้า & สาขา</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  ชื่อร้านค้า (Store Name) *
                </label>
                <input
                  type="text"
                  required
                  value={formData.storeName}
                  onChange={(e) => setFormData({ ...formData, storeName: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  ชื่อสาขา (Branch Name)
                </label>
                <input
                  type="text"
                  value={formData.branchName}
                  onChange={(e) => setFormData({ ...formData, branchName: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  เลขประจำตัวผู้เสียภาษี (Tax ID 13 หลัก)
                </label>
                <input
                  type="text"
                  value={formData.taxId}
                  onChange={(e) => setFormData({ ...formData, taxId: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-white font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  เบอร์โทรศัพท์ติดต่อร้าน
                </label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  PromptPay ID (เบอร์โทร / เลขนิติบุคคล สำหรับสร้าง QR)
                </label>
                <input
                  type="text"
                  value={formData.promptPayId}
                  onChange={(e) => setFormData({ ...formData, promptPayId: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-white font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  ชื่อพนักงานแคชเชียร์ปัจจุบัน
                </label>
                <input
                  type="text"
                  value={formData.cashierName}
                  onChange={(e) => setFormData({ ...formData, cashierName: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  ที่อยู่ร้านค้า (แสดงบนหัวใบเสร็จรับเงิน)
                </label>
                <textarea
                  rows={2}
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PRINTER SETTINGS */}
        {activeTab === 'printer' && (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-md space-y-5">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-800 pb-3 flex items-center gap-2">
              <Printer className="w-4 h-4 text-emerald-500" />
              <span>เครื่องพิมพ์ความร้อน & ใบเสร็จ</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
                  ขนาดหน้ากว้างกระดาษเครื่องพิมพ์ (Paper Width)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, printerType: 'thermal_80mm' })}
                    className={`p-3 rounded-2xl border text-xs font-bold transition-all ${
                      formData.printerType === 'thermal_80mm'
                        ? 'bg-emerald-50 dark:bg-emerald-500/20 border-emerald-500 text-emerald-700 dark:text-emerald-400 shadow-xs'
                        : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    <div>ขนาด 80 mm</div>
                    <div className="text-[10px] font-normal text-slate-500 mt-0.5">
                      มาตรฐานตั้งโต๊ะ ESC/POS
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, printerType: 'thermal_58mm' })}
                    className={`p-3 rounded-2xl border text-xs font-bold transition-all ${
                      formData.printerType === 'thermal_58mm'
                        ? 'bg-emerald-50 dark:bg-emerald-500/20 border-emerald-500 text-emerald-700 dark:text-emerald-400 shadow-xs'
                        : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    <div>ขนาด 58 mm</div>
                    <div className="text-[10px] font-normal text-slate-500 mt-0.5">
                      พกพา / บลูทูธไร้สาย
                    </div>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
                  การพิมพ์อัตโนมัติ
                </label>
                <label className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.autoPrintReceipt}
                    onChange={(e) =>
                      setFormData({ ...formData, autoPrintReceipt: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-emerald-500 focus:ring-0 bg-white dark:bg-slate-900 border-slate-300 dark:border-slate-700"
                  />
                  <div>
                    <span className="text-xs font-semibold text-slate-900 dark:text-white block">
                      เปิดหน้าต่างใบเสร็จอัตโนมัติเมื่อชำระเงินเสร็จ
                    </span>
                    <span className="text-[10px] text-slate-500">
                      แสดง Receipt Preview พร้อมปุ่มพิมพ์ทันที
                    </span>
                  </div>
                </label>
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  ข้อความท้ายใบเสร็จ (Receipt Footer Note)
                </label>
                <input
                  type="text"
                  value={formData.receiptFooterMessage}
                  onChange={(e) =>
                    setFormData({ ...formData, receiptFooterMessage: e.target.value })
                  }
                  placeholder="ขอบคุณที่ใช้บริการ / Thank you"
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: TAX & FINANCIALS */}
        {activeTab === 'tax' && (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-md space-y-5">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-800 pb-3 flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-500" />
              <span>อัตราภาษี & การแสดงผลทศนิยม</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  อัตราภาษีมูลค่าเพิ่ม (VAT %)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={formData.vatRate}
                    onChange={(e) =>
                      setFormData({ ...formData, vatRate: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-emerald-600 dark:text-emerald-400 font-bold focus:outline-none focus:border-emerald-500"
                  />
                  <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-xs">
                    %
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  รูปแบบการคำนวณ VAT
                </label>
                <select
                  value={formData.vatType}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      vatType: e.target.value as 'included' | 'excluded',
                    })
                  }
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="included">รวมในราคาสินค้าแล้ว (VAT Included 7%)</option>
                  <option value="excluded">คิดแยกนอกยอดรวม (VAT Excluded +7%)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  จำนวนตำแหน่งทศนิยมราคา (Decimal Places)
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[0, 2, 3].map((dec) => (
                    <button
                      key={dec}
                      type="button"
                      onClick={() => setFormData({ ...formData, decimalPlaces: dec })}
                      className={`p-2.5 rounded-xl border text-xs font-bold transition-all ${
                        formData.decimalPlaces === dec
                          ? 'bg-emerald-50 dark:bg-emerald-500/20 border-emerald-500 text-emerald-700 dark:text-emerald-400 shadow-xs'
                          : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      <div>{dec} ตำแหน่ง</div>
                      <div className="text-[10px] font-mono text-slate-500 mt-0.5">
                        {dec === 0 ? '฿120' : dec === 2 ? '฿120.00' : '฿120.000'}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  สัญลักษณ์สกุลเงิน (Currency Symbol)
                </label>
                <input
                  type="text"
                  value={formData.currencySymbol}
                  onChange={(e) =>
                    setFormData({ ...formData, currencySymbol: e.target.value })
                  }
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-white font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: BACKUP & DATA RESET */}
        {activeTab === 'data' && (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-md space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-800 pb-3 flex items-center gap-2">
              <Database className="w-4 h-4 text-emerald-500" />
              <span>การจัดการข้อมูล & สำรองฐานข้อมูล</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">สำรองข้อมูลทั้งหมด (Backup Export)</h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  ดาวน์โหลดไฟล์ .json บรรจุข้อมูลสินค้า ประวัติบิล ยอดสต็อก และการตั้งค่า
                </p>
                <button
                  type="button"
                  onClick={handleExportBackup}
                  className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 text-xs font-semibold shadow-xs"
                >
                  <Download className="w-4 h-4 text-emerald-600 dark:text-cyan-400" />
                  <span>ดาวน์โหลดไฟล์สำรอง</span>
                </button>
              </div>

              <div className="p-4 bg-rose-50 dark:bg-rose-950/20 rounded-2xl border border-rose-200 dark:border-rose-900/40 space-y-2">
                <h4 className="text-xs font-bold text-rose-800 dark:text-rose-300">รีเซ็ตข้อมูลระบบเป็นค่าเริ่มต้น</h4>
                <p className="text-[11px] text-rose-700 dark:text-rose-400/80">
                  ล้างข้อมูลและโหลดชุดสินค้า เมนู และบิลตัวอย่างใหม่ทั้งหมด
                </p>
                <button
                  type="button"
                  onClick={handleResetData}
                  className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-rose-100 dark:bg-rose-600/30 hover:bg-rose-200 dark:hover:bg-rose-600/50 text-rose-800 dark:text-rose-300 border border-rose-300 dark:border-rose-500/40 text-xs font-bold shadow-xs"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>รีเซ็ตข้อมูลตัวอย่าง</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Save Button Bar */}
        <div className="flex justify-end gap-3 pt-2">
          <button
            type="submit"
            id="save-settings-btn"
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all scale-[1.01] active:scale-[0.99]"
          >
            <Save className="w-4 h-4" />
            <span>บันทึกการตั้งค่า (Save Settings)</span>
          </button>
        </div>
      </form>
    </div>
  );
};
