import React, { useState, useEffect } from 'react';
import { PosProvider, usePos } from './context/PosContext';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { PosView } from './components/PosView';
import { DashboardView } from './components/DashboardView';
import { BillsView } from './components/BillsView';
import { ProductsView } from './components/ProductsView';
import { StockView } from './components/StockView';
import { ReportsView } from './components/ReportsView';
import { SettingsView } from './components/SettingsView';
import { CustomerDisplayView } from './components/CustomerDisplayView';
import { PaymentModal } from './components/PaymentModal';
import { ReceiptModal } from './components/ReceiptModal';

const PosAppContent: React.FC = () => {
  const { activeTab, setActiveTab } = usePos();
  const [isStandaloneCustomerDisplay, setIsStandaloneCustomerDisplay] = useState(false);

  useEffect(() => {
    // Check if opened as standalone secondary customer display window
    const searchParams = new URLSearchParams(window.location.search);
    const displayParam = searchParams.get('display');
    const viewParam = searchParams.get('view');
    const modeParam = searchParams.get('mode');
    if (
      displayParam === 'customer' ||
      displayParam === 'front' ||
      viewParam === 'customer-display' ||
      viewParam === 'customer' ||
      modeParam === 'customer'
    ) {
      setIsStandaloneCustomerDisplay(true);
    }
  }, []);

  const handleOpenQuickSearch = () => {
    setActiveTab('pos');
    setTimeout(() => {
      const searchInput = document.getElementById('pos-search-input');
      if (searchInput) {
        searchInput.focus();
      }
    }, 100);
  };

  // If in dedicated standalone customer display mode (e.g. secondary monitor / window)
  if (isStandaloneCustomerDisplay) {
    return (
      <div className="h-screen w-full bg-slate-50 text-slate-900 flex flex-col font-sans overflow-hidden">
        <CustomerDisplayView isStandaloneWindow={true} />
      </div>
    );
  }

  return (
    <div className="h-screen w-full bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans selection:bg-red-600 selection:text-white overflow-hidden transition-colors">
      {/* Top Navigation Bar */}
      <Navbar onOpenQuickSearch={handleOpenQuickSearch} />

      {/* Main View Area */}
      <main className="flex-1 flex flex-col min-h-0 overflow-hidden relative">
        {activeTab === 'pos' && <PosView />}
        {activeTab === 'dashboard' && <DashboardView />}
        {activeTab === 'bills' && <BillsView />}
        {activeTab === 'products' && <ProductsView />}
        {activeTab === 'stock' && <StockView />}
        {activeTab === 'reports' && <ReportsView />}
        {activeTab === 'settings' && <SettingsView />}
        {activeTab === 'customer-display' && <CustomerDisplayView />}
      </main>

      {/* Bottom Floating Navigation Dock */}
      <BottomNav />

      {/* Global Modals */}
      <ReceiptModal />
    </div>
  );
};

export default function App() {
  return (
    <PosProvider>
      <PosAppContent />
    </PosProvider>
  );
}

