import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import {
  Product,
  CartItem,
  Order,
  OrderItem,
  HeldOrder,
  StockMovement,
  Supplier,
  StoreSettings,
  Category,
  UnitItem,
  NoteOption,
} from '../types';
import {
  INITIAL_SETTINGS,
  INITIAL_PRODUCTS,
  INITIAL_SUPPLIERS,
  INITIAL_HELD_ORDERS,
  INITIAL_ORDERS,
  INITIAL_STOCK_MOVEMENTS,
  INITIAL_CATEGORIES,
  INITIAL_UNITS,
  INITIAL_NOTE_OPTIONS,
} from '../data/mockData';
import confetti from 'canvas-confetti';

interface PosContextType {
  activeTab: 'dashboard' | 'pos' | 'bills' | 'products' | 'stock' | 'reports' | 'settings' | 'customer-display';
  setActiveTab: (tab: 'dashboard' | 'pos' | 'bills' | 'products' | 'stock' | 'reports' | 'settings' | 'customer-display') => void;
  
  // Theme
  theme: 'light' | 'dark';
  setTheme: (theme: 'light' | 'dark') => void;
  toggleTheme: () => void;

  // Settings
  settings: StoreSettings;
  updateSettings: (newSettings: Partial<StoreSettings>) => void;

  // Categories & Units
  categories: Category[];
  addCategory: (category: Omit<Category, 'id'>) => Category;
  updateCategory: (id: string, updated: Partial<Category>) => void;
  deleteCategory: (id: string) => void;

  units: UnitItem[];
  addUnit: (name: string) => UnitItem;
  updateUnit: (id: string, name: string) => void;
  deleteUnit: (id: string) => void;

  // Note Options (ตัวเลือกโน้ต & ส่วนผสม)
  noteOptions: NoteOption[];
  addNoteOption: (note: Omit<NoteOption, 'id'>) => NoteOption;
  updateNoteOption: (id: string, updated: Partial<NoteOption>) => void;
  deleteNoteOption: (id: string) => void;

  // Products
  products: Product[];
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, updated: Partial<Product>) => void;
  deleteProduct: (id: string) => void;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number, note?: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  updateCartItemNote: (productId: string, note: string) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  discount: number;
  discountType: 'amount' | 'percent';
  setDiscount: (amount: number, type?: 'amount' | 'percent') => void;
  cartTotals: {
    itemCount: number;
    subtotal: number;
    discountAmount: number;
    netBeforeVat: number;
    vatAmount: number;
    total: number;
  };

  // Customer Display synchronization helper
  broadcastCustomerDisplay: (data: {
    type: 'CART_UPDATE' | 'PAYMENT_MODAL_STATE' | 'ORDER_COMPLETED' | 'CLEAR_THANK_YOU';
    payload: any;
  }) => void;
  openCustomerDisplayWindow: () => void;

  // Held Orders
  heldOrders: HeldOrder[];
  holdCurrentCart: (customerName?: string, note?: string) => boolean;
  resumeHeldOrder: (heldId: string) => void;
  deleteHeldOrder: (heldId: string) => void;
  batchDeleteHeldOrders: (heldIds: string[]) => void;
  mergeHeldOrdersIntoCart: (heldIds: string[]) => void;
  processBatchHeldPayment: (params: {
    heldIds: string[];
    paymentMethod: 'cash' | 'promptpay' | 'card' | 'transfer';
    cashReceived?: number;
    referenceNumber?: string;
    customerNote?: string;
  }) => Order | null;

  // Orders
  orders: Order[];
  processPayment: (params: {
    paymentMethod: 'cash' | 'promptpay' | 'card' | 'transfer';
    cashReceived?: number;
    referenceNumber?: string;
    customerNote?: string;
  }) => Order;
  refundOrder: (orderId: string, reason?: string) => void;
  cancelOrder: (orderId: string) => void;

  // Stock Management
  stockMovements: StockMovement[];
  stockIn: (productId: string, quantity: number, supplierName: string, reason: string, cost?: number) => void;
  stockOut: (productId: string, quantity: number, reason: string) => void;
  adjustStock: (productId: string, newStock: number, reason: string) => void;
  batchStockOperation: (params: {
    type: 'in' | 'out' | 'adjust';
    items: Array<{
      productId: string;
      quantity: number; // for adjust: target stock count, for in/out: quantity delta
      cost?: number;
      note?: string;
    }>;
    supplierName?: string;
    reason: string;
    referenceNo?: string;
  }) => void;

  // Suppliers
  suppliers: Supplier[];
  addSupplier: (supplier: Omit<Supplier, 'id' | 'productsCount'>) => void;
  updateSupplier: (id: string, supplier: Partial<Supplier>) => void;
  deleteSupplier: (id: string) => void;

  // Receipt Modal State
  selectedOrderForReceipt: Order | null;
  setSelectedOrderForReceipt: (order: Order | null) => void;

  // Audio & Toast Helpers
  playBeep: (type?: 'beep' | 'success' | 'alert' | 'info') => void;
  toast: { message: string; type: 'success' | 'info' | 'error' | 'warning' } | null;
  showToast: (message: string, type?: 'success' | 'info' | 'error' | 'warning') => void;
}

const PosContext = createContext<PosContextType | undefined>(undefined);

// Web Audio API Sound Synthesizer
const playAudioTone = (type: 'beep' | 'success' | 'alert' | 'info' = 'beep') => {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === 'beep' || type === 'info') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime); // A5
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
      osc.start();
      osc.stop(ctx.currentTime + 0.08);
    } else if (type === 'success') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.setValueAtTime(880, ctx.currentTime + 0.08); // A5
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } else if (type === 'alert') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(330, ctx.currentTime);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.2);
      osc.start();
      osc.stop(ctx.currentTime + 0.2);
    }
  } catch (e) {
    console.debug('Audio not supported or blocked:', e);
  }
};

export const PosProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'pos' | 'bills' | 'products' | 'stock' | 'reports' | 'settings'>('pos');
  
  // Local storage synced states with fallback
  const [settings, setSettings] = useState<StoreSettings>(() => {
    const saved = localStorage.getItem('siampure_settings');
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });

  const [theme, setThemeState] = useState<'light' | 'dark'>(() => {
    const saved = localStorage.getItem('siampure_theme');
    if (saved === 'dark' || saved === 'light') return saved;
    return 'light';
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem('siampure_categories');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });

  const [units, setUnits] = useState<UnitItem[]>(() => {
    const saved = localStorage.getItem('siampure_units');
    return saved ? JSON.parse(saved) : INITIAL_UNITS;
  });

  const [noteOptions, setNoteOptions] = useState<NoteOption[]>(() => {
    const saved = localStorage.getItem('siampure_note_options');
    return saved ? JSON.parse(saved) : INITIAL_NOTE_OPTIONS;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('siampure_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('siampure_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [discount, setDiscountState] = useState<number>(() => {
    const saved = localStorage.getItem('siampure_discount');
    return saved ? JSON.parse(saved) : 0;
  });
  const [discountType, setDiscountTypeState] = useState<'amount' | 'percent'>(() => {
    const saved = localStorage.getItem('siampure_discount_type');
    return (saved === 'percent' || saved === 'amount') ? saved : 'amount';
  });

  const [heldOrders, setHeldOrders] = useState<HeldOrder[]>(() => {
    const saved = localStorage.getItem('siampure_held_orders');
    return saved ? JSON.parse(saved) : INITIAL_HELD_ORDERS;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('siampure_orders');
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [stockMovements, setStockMovements] = useState<StockMovement[]>(() => {
    const saved = localStorage.getItem('siampure_stock_movements');
    return saved ? JSON.parse(saved) : INITIAL_STOCK_MOVEMENTS;
  });

  const [suppliers, setSuppliers] = useState<Supplier[]>(() => {
    const saved = localStorage.getItem('siampure_suppliers');
    return saved ? JSON.parse(saved) : INITIAL_SUPPLIERS;
  });

  const [selectedOrderForReceipt, setSelectedOrderForReceipt] = useState<Order | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'error' | 'warning' } | null>(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('siampure_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('siampure_theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const setTheme = (newTheme: 'light' | 'dark') => {
    setThemeState(newTheme);
    setSettings((prev) => ({ ...prev, theme: newTheme }));
  };

  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    showToast(`สลับเป็นโหมด${next === 'dark' ? 'มืด (Dark Mode)' : 'สว่าง (White Mode)'}`, 'info');
  };

  useEffect(() => {
    localStorage.setItem('siampure_categories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('siampure_units', JSON.stringify(units));
  }, [units]);

  useEffect(() => {
    localStorage.setItem('siampure_note_options', JSON.stringify(noteOptions));
  }, [noteOptions]);

  useEffect(() => {
    localStorage.setItem('siampure_products', JSON.stringify(products));
  }, [products]);

  const isDisplayCustomerUrl = typeof window !== 'undefined' && (
    window.location.search.includes('display=customer') ||
    window.location.search.includes('display=front') ||
    window.location.search.includes('view=customer-display') ||
    window.location.search.includes('view=customer') ||
    window.location.search.includes('mode=customer')
  );

  useEffect(() => {
    if (!isDisplayCustomerUrl) {
      localStorage.setItem('siampure_cart', JSON.stringify(cart));
    }
  }, [cart, isDisplayCustomerUrl]);

  useEffect(() => {
    if (!isDisplayCustomerUrl) {
      localStorage.setItem('siampure_discount', JSON.stringify(discount));
      localStorage.setItem('siampure_discount_type', discountType);
    }
  }, [discount, discountType, isDisplayCustomerUrl]);

  // Cross-tab / Cross-window state synchronization
  useEffect(() => {
    const handleStorage = (e: StorageEvent) => {
      if (!e.newValue) return;
      try {
        if (e.key === 'siampure_cart') {
          setCart(JSON.parse(e.newValue));
        } else if (e.key === 'siampure_discount') {
          setDiscountState(JSON.parse(e.newValue));
        } else if (e.key === 'siampure_discount_type') {
          if (e.newValue === 'percent' || e.newValue === 'amount') {
            setDiscountTypeState(e.newValue);
          }
        } else if (e.key === 'siampure_orders') {
          setOrders(JSON.parse(e.newValue));
        } else if (e.key === 'siampure_held_orders') {
          setHeldOrders(JSON.parse(e.newValue));
        } else if (e.key === 'siampure_products') {
          setProducts(JSON.parse(e.newValue));
        } else if (e.key === 'siampure_categories') {
          setCategories(JSON.parse(e.newValue));
        } else if (e.key === 'siampure_settings') {
          setSettings(JSON.parse(e.newValue));
        }
      } catch (err) {
        console.error('Storage sync error:', err);
      }
    };

    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  useEffect(() => {
    localStorage.setItem('siampure_held_orders', JSON.stringify(heldOrders));
  }, [heldOrders]);

  useEffect(() => {
    localStorage.setItem('siampure_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('siampure_stock_movements', JSON.stringify(stockMovements));
  }, [stockMovements]);

  useEffect(() => {
    localStorage.setItem('siampure_suppliers', JSON.stringify(suppliers));
  }, [suppliers]);

  const showToast = (message: string, type: 'success' | 'info' | 'error' | 'warning' = 'info') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3500);
  };

  const playBeep = (type: 'beep' | 'success' | 'alert' | 'info' = 'beep') => {
    if (settings.enableSoundEffects) {
      playAudioTone(type);
    }
  };

  const updateSettings = (newSettings: Partial<StoreSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
    if (newSettings.theme) {
      setThemeState(newSettings.theme);
    }
    showToast('บันทึกการตั้งค่าเรียบร้อยแล้ว', 'success');
  };

  // Categories CRUD
  const addCategory = (catData: Omit<Category, 'id'>): Category => {
    const newCat: Category = {
      ...catData,
      id: catData.name.toLowerCase().replace(/[^a-z0-9]/g, '-') || `cat-${Date.now()}`,
    };
    // Ensure unique id
    if (categories.some((c) => c.id === newCat.id)) {
      newCat.id = `${newCat.id}-${Date.now().toString().slice(-4)}`;
    }
    setCategories((prev) => [...prev, newCat]);
    showToast(`เพิ่มหมวดหมู่ "${newCat.name}" สำเร็จ`, 'success');
    return newCat;
  };

  const updateCategory = (id: string, updated: Partial<Category>) => {
    setCategories((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updated } : c))
    );
    showToast('อัปเดตหมวดหมู่สำเร็จ', 'success');
  };

  const deleteCategory = (id: string) => {
    const isUsed = products.some((p) => p.category === id);
    if (isUsed) {
      showToast('ไม่สามารถลบหมวดหมู่นี้ได้เนื่องจากมีสินค้าใช้งานอยู่', 'warning');
      return;
    }
    setCategories((prev) => prev.filter((c) => c.id !== id));
    showToast('ลบหมวดหมู่เรียบร้อยแล้ว', 'info');
  };

  // Units CRUD
  const addUnit = (name: string): UnitItem => {
    const trimmed = name.trim();
    const existing = units.find((u) => u.name.toLowerCase() === trimmed.toLowerCase());
    if (existing) return existing;

    const newUnit: UnitItem = {
      id: `unit-${Date.now()}`,
      name: trimmed,
    };
    setUnits((prev) => [...prev, newUnit]);
    showToast(`เพิ่มหน่วยนับ "${trimmed}" สำเร็จ`, 'success');
    return newUnit;
  };

  const updateUnit = (id: string, name: string) => {
    setUnits((prev) =>
      prev.map((u) => (u.id === id ? { ...u, name: name.trim() } : u))
    );
    showToast('อัปเดตหน่วยนับสำเร็จ', 'success');
  };

  const deleteUnit = (id: string) => {
    const targetUnit = units.find((u) => u.id === id);
    if (targetUnit && products.some((p) => p.unit === targetUnit.name)) {
      showToast('ไม่สามารถลบหน่วยนี้ได้เนื่องจากมีสินค้าใช้งานอยู่', 'warning');
      return;
    }
    setUnits((prev) => prev.filter((u) => u.id !== id));
    showToast('ลบหน่วยนับเรียบร้อยแล้ว', 'info');
  };

  // Note Options CRUD (การจัดการโน้ต & ตัวเลือกเพิ่มเติม)
  const addNoteOption = (noteData: Omit<NoteOption, 'id'>): NoteOption => {
    const newNote: NoteOption = {
      ...noteData,
      id: `note-${Date.now()}`,
    };
    setNoteOptions((prev) => [...prev, newNote]);
    showToast(`เพิ่มตัวเลือกโน้ต "${newNote.name}" สำเร็จ`, 'success');
    return newNote;
  };

  const updateNoteOption = (id: string, updated: Partial<NoteOption>) => {
    setNoteOptions((prev) =>
      prev.map((n) => (n.id === id ? { ...n, ...updated } : n))
    );
    showToast('อัปเดตตัวเลือกโน้ตสำเร็จ', 'success');
  };

  const deleteNoteOption = (id: string) => {
    // Also unbind from any products that currently have this noteOptionId
    setProducts((prev) =>
      prev.map((p) => ({
        ...p,
        noteOptionIds: (p.noteOptionIds || []).filter((nid) => nid !== id),
      }))
    );
    setNoteOptions((prev) => prev.filter((n) => n.id !== id));
    showToast('ลบตัวเลือกโน้ตเรียบร้อยแล้ว', 'info');
  };

  // Cart Calculations
  const cartTotals = React.useMemo(() => {
    const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    
    let discountAmount = 0;
    if (discountType === 'percent') {
      discountAmount = (subtotal * discount) / 100;
    } else {
      discountAmount = discount;
    }
    discountAmount = Math.min(discountAmount, subtotal);

    const netBeforeVat = subtotal - discountAmount;
    let vatAmount = 0;
    let total = netBeforeVat;

    if (settings.vatType === 'included') {
      // VAT is already in price: total = netBeforeVat, VAT = netBeforeVat * 7 / 107
      vatAmount = (netBeforeVat * settings.vatRate) / (100 + settings.vatRate);
      total = netBeforeVat;
    } else {
      // VAT is added on top
      vatAmount = (netBeforeVat * settings.vatRate) / 100;
      total = netBeforeVat + vatAmount;
    }

    return {
      itemCount,
      subtotal,
      discountAmount,
      netBeforeVat,
      vatAmount,
      total,
    };
  }, [cart, discount, discountType, settings.vatRate, settings.vatType]);

  // Customer Display Multi-Layer Synchronization Helper
  const broadcastChannelRef = useRef<BroadcastChannel | null>(null);
  const customerWindowsRef = useRef<Window[]>([]);

  // Function to open standalone Customer Display Window
  const openCustomerDisplayWindow = () => {
    const url = `${window.location.origin}${window.location.pathname}?display=customer`;
    const popup = window.open(
      url,
      'siampure_pos_customer_window',
      'width=1024,height=768,menubar=no,toolbar=no,location=no,status=no,resizable=yes'
    );
    if (popup) {
      try {
        (popup as any).__SIAMPURE_INITIAL_STATE__ = {
          cart,
          cartTotals,
          discount,
          discountType,
          settings,
        };
        customerWindowsRef.current.push(popup);
      } catch (e) {
        // ignore
      }
    } else {
      setActiveTab('customer-display');
    }
  };

  // BroadcastChannel Handshake
  useEffect(() => {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        const bc = new BroadcastChannel('siampure_pos_customer_display');
        bc.onmessage = (event) => {
          if (event.data?.type === 'REQUEST_CURRENT_STATE' || event.data?.type === 'CUSTOMER_DISPLAY_MOUNTED') {
            // Respond with current cart state
            bc.postMessage({
              type: 'CART_UPDATE',
              payload: {
                cart,
                cartTotals,
                discount,
                discountType,
                settings,
              },
            });
          }
        };
        broadcastChannelRef.current = bc;
      } catch (e) {
        console.warn('BroadcastChannel error:', e);
      }
    }
    return () => {
      if (broadcastChannelRef.current) {
        try {
          broadcastChannelRef.current.close();
        } catch (e) {
          // ignore
        }
      }
    };
  }, [cart, cartTotals, discount, discountType, settings]);

  // Window postMessage listener (Solves Chrome iframe partition isolation)
  useEffect(() => {
    const handleWindowMessage = (event: MessageEvent) => {
      if (!event.data || typeof event.data !== 'object') return;
      const { type } = event.data;

      if (type === 'REQUEST_CURRENT_STATE' || type === 'CUSTOMER_DISPLAY_MOUNTED') {
        const payload = {
          cart,
          cartTotals,
          discount,
          discountType,
          settings,
        };

        if (event.source && 'postMessage' in event.source) {
          try {
            (event.source as Window).postMessage(
              {
                type: 'CART_UPDATE',
                payload,
              },
              '*'
            );
          } catch (e) {
            // ignore
          }
        }

        if (event.source && typeof (event.source as Window).closed !== 'undefined') {
          const win = event.source as Window;
          if (!customerWindowsRef.current.includes(win)) {
            customerWindowsRef.current.push(win);
          }
        }
      }
    };

    window.addEventListener('message', handleWindowMessage);
    return () => window.removeEventListener('message', handleWindowMessage);
  }, [cart, cartTotals, discount, discountType, settings]);

  const broadcastCustomerDisplay = (data: {
    type: 'CART_UPDATE' | 'PAYMENT_MODAL_STATE' | 'ORDER_COMPLETED' | 'CLEAR_THANK_YOU';
    payload: any;
  }) => {
    try {
      // 1. BroadcastChannel for cross-tab/cross-window
      if (broadcastChannelRef.current) {
        broadcastChannelRef.current.postMessage(data);
      }
      // 2. CustomEvent for same-window component listeners
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('siampure_customer_event', { detail: data }));
      }
      // 3. LocalStorage for fallback storage event
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('siampure_customer_payment_event', JSON.stringify({
          type: data.type,
          ...data.payload,
          _timestamp: Date.now(),
        }));
      }
      // 4. Direct window postMessage to all tracked customer popups
      customerWindowsRef.current = customerWindowsRef.current.filter((w) => {
        try {
          return !w.closed;
        } catch {
          return false;
        }
      });
      customerWindowsRef.current.forEach((w) => {
        try {
          w.postMessage(data, '*');
          (w as any).__SIAMPURE_LATEST_STATE__ = data;
        } catch (e) {
          // ignore
        }
      });
    } catch (e) {
      console.warn('BroadcastCustomerDisplay error:', e);
    }
  };

  // Products CRUD
  const addProduct = (productData: Omit<Product, 'id'>) => {
    const newProduct: Product = {
      ...productData,
      id: 'prod-' + Date.now(),
    };
    setProducts((prev) => [newProduct, ...prev]);
    showToast(`เพิ่มสินค้า "${newProduct.name}" สำเร็จ`, 'success');
    playBeep('success');
  };

  const updateProduct = (id: string, updated: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updated } : p))
    );
    showToast('อัปเดตข้อมูลสินค้าสำเร็จ', 'success');
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
    showToast('ลบสินค้าออกจากระบบแล้ว', 'info');
  };

  // Cart operations
  const addToCart = (product: Product, quantity = 1, note = '') => {
    if (product.stock <= 0) {
      showToast(`สินค้า "${product.name}" หมดสต็อกแล้ว!`, 'error');
      playBeep('alert');
      return;
    }

    setCart((prevCart) => {
      const existingIndex = prevCart.findIndex(
        (item) => item.product.id === product.id && (item.note || '') === (note || '')
      );

      if (existingIndex > -1) {
        const updated = [...prevCart];
        const newQty = updated[existingIndex].quantity + quantity;
        if (newQty > product.stock) {
          showToast(`สินค้าในสต็อกมีเพียง ${product.stock} ${product.unit}`, 'warning');
          return prevCart;
        }
        updated[existingIndex].quantity = newQty;
        return updated;
      } else {
        return [...prevCart, { product, quantity, note }];
      }
    });

    playBeep('beep');
    showToast(`เพิ่ม "${product.name}" ลงตะกร้าแล้ว`, 'info');
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }

    setCart((prevCart) =>
      prevCart.map((item) => {
        if (item.product.id === productId) {
          if (quantity > item.product.stock) {
            showToast(`สต็อกไม่เพียงพอ (คงเหลือ ${item.product.stock})`, 'warning');
            return item;
          }
          return { ...item, quantity };
        }
        return item;
      })
    );
    playBeep('beep');
  };

  const updateCartItemNote = (productId: string, note: string) => {
    setCart((prevCart) =>
      prevCart.map((item) =>
        item.product.id === productId ? { ...item, note } : item
      )
    );
  };

  const removeFromCart = (productId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.product.id !== productId));
    playBeep('alert');
  };

  const clearCart = () => {
    setCart([]);
    setDiscountState(0);
  };

  const setDiscount = (amount: number, type: 'amount' | 'percent' = 'amount') => {
    setDiscountState(amount);
    setDiscountTypeState(type);
  };

  // Real-time broadcast cart & totals to Customer Display
  useEffect(() => {
    broadcastCustomerDisplay({
      type: 'CART_UPDATE',
      payload: {
        cart,
        cartTotals,
        discount,
        discountType,
      },
    });
  }, [cart, cartTotals, discount, discountType]);

  // Held Orders (พักยอดบิล)
  const holdCurrentCart = (customerName?: string, note?: string): boolean => {
    if (cart.length === 0) {
      showToast('ไม่มีสินค้าในตะกร้าสำหรับพักยอด', 'warning');
      return false;
    }

    const heldNumber = `HOLD-${String(heldOrders.length + 1).padStart(3, '0')}`;
    const newHeldOrder: HeldOrder = {
      id: 'hold-' + Date.now(),
      heldNumber,
      customerName: customerName || `ลูกค้าพักยอด #${heldOrders.length + 1}`,
      items: [...cart],
      subtotal: cartTotals.subtotal,
      discount,
      discountType,
      note,
      createdAt: new Date().toISOString(),
      total: cartTotals.total,
    };

    setHeldOrders((prev) => [newHeldOrder, ...prev]);
    clearCart();
    playBeep('success');
    showToast(`พักยอดบิล ${heldNumber} เรียบร้อยแล้ว`, 'success');
    return true;
  };

  const resumeHeldOrder = (heldId: string) => {
    const found = heldOrders.find((h) => h.id === heldId);
    if (!found) return;

    if (cart.length > 0) {
      const confirmReplace = window.confirm('มีสินค้าอยู่ในตะกร้า ต้องการแทนที่ด้วยรายการพักยอดนี้หรือไม่?');
      if (!confirmReplace) return;
    }

    setCart(found.items);
    setDiscountState(found.discount);
    setDiscountTypeState(found.discountType);
    setHeldOrders((prev) => prev.filter((h) => h.id !== heldId));
    setActiveTab('pos');
    playBeep('success');
    showToast(`ดึงรายการพักยอด ${found.heldNumber} กลับมาขายแล้ว`, 'success');
  };

  const deleteHeldOrder = (heldId: string) => {
    setHeldOrders((prev) => prev.filter((h) => h.id !== heldId));
    showToast('ลบรายการพักยอดแล้ว', 'info');
  };

  const batchDeleteHeldOrders = (heldIds: string[]) => {
    if (heldIds.length === 0) return;
    setHeldOrders((prev) => prev.filter((h) => !heldIds.includes(h.id)));
    showToast(`ลบรายการพักยอดจำนวน ${heldIds.length} รายการแล้ว`, 'info');
  };

  const mergeHeldOrdersIntoCart = (heldIds: string[]) => {
    const targets = heldOrders.filter((h) => heldIds.includes(h.id));
    if (targets.length === 0) return;

    setCart((prevCart) => {
      let updatedCart = [...prevCart];
      targets.forEach((held) => {
        held.items.forEach((heldItem) => {
          const existingIdx = updatedCart.findIndex(
            (it) => it.product.id === heldItem.product.id && (it.note || '') === (heldItem.note || '')
          );
          if (existingIdx > -1) {
            const currentItem = updatedCart[existingIdx];
            const maxStock = currentItem.product.stock;
            const newQty = Math.min(maxStock, currentItem.quantity + heldItem.quantity);
            updatedCart[existingIdx] = { ...currentItem, quantity: newQty };
          } else {
            updatedCart.push({ ...heldItem });
          }
        });
      });
      return updatedCart;
    });

    setHeldOrders((prev) => prev.filter((h) => !heldIds.includes(h.id)));
    setActiveTab('pos');
    playBeep('success');
    showToast(`รวม ${targets.length} รายการพักยอดเข้าสู่ตะกร้าเรียบร้อยแล้ว`, 'success');
  };

  const processBatchHeldPayment = ({
    heldIds,
    paymentMethod,
    cashReceived,
    referenceNumber,
    customerNote,
  }: {
    heldIds: string[];
    paymentMethod: 'cash' | 'promptpay' | 'card' | 'transfer';
    cashReceived?: number;
    referenceNumber?: string;
    customerNote?: string;
  }): Order | null => {
    const targets = heldOrders.filter((h) => heldIds.includes(h.id));
    if (targets.length === 0) {
      showToast('ไม่พบรายการพักยอดที่เลือก', 'error');
      return null;
    }

    // Consolidate all items
    const rawItems: OrderItem[] = [];
    let subtotal = 0;
    let totalDiscountAmount = 0;

    targets.forEach((h) => {
      // Calculate discount for each held order
      let dAmt = 0;
      if (h.discountType === 'percent') {
        dAmt = (h.subtotal * h.discount) / 100;
      } else {
        dAmt = h.discount || 0;
      }
      totalDiscountAmount += Math.min(dAmt, h.subtotal);

      h.items.forEach((item) => {
        const itemLineTotal = item.product.price * item.quantity;
        subtotal += itemLineTotal;
        rawItems.push({
          productId: item.product.id,
          name: item.product.name,
          sku: item.product.sku,
          price: item.product.price,
          cost: item.product.cost,
          quantity: item.quantity,
          total: itemLineTotal,
          note: item.note ? `${item.note} [${h.heldNumber}]` : `[${h.heldNumber}]`,
        });
      });
    });

    // Compute Tax & Final Total
    const netBeforeVat = Math.max(0, subtotal - totalDiscountAmount);
    let vatAmount = 0;
    let total = netBeforeVat;

    if (settings.vatType === 'included') {
      vatAmount = (netBeforeVat * settings.vatRate) / (100 + settings.vatRate);
      total = netBeforeVat;
    } else {
      vatAmount = (netBeforeVat * settings.vatRate) / 100;
      total = netBeforeVat + vatAmount;
    }

    const orderSeq = String(orders.length + 1).padStart(4, '0');
    const datePrefix = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const orderNumber = `INV-${datePrefix}-${orderSeq}`;

    const change = cashReceived ? Math.max(0, cashReceived - total) : 0;

    const heldRefTags = targets.map((h) => `${h.heldNumber}${h.customerName ? ` (${h.customerName})` : ''}`).join(', ');
    const finalNote = [
      `ชำระรวม ${targets.length} รายการพักยอด: ${heldRefTags}`,
      customerNote,
    ]
      .filter(Boolean)
      .join(' • ');

    const newOrder: Order = {
      id: 'ord-' + Date.now(),
      orderNumber,
      items: rawItems,
      subtotal,
      discount: totalDiscountAmount,
      discountType: 'amount',
      vatRate: settings.vatRate,
      vatAmount,
      isVatIncluded: settings.vatType === 'included',
      total,
      paymentMethod,
      cashReceived,
      change,
      status: 'completed',
      createdAt: new Date().toISOString(),
      cashierName: settings.cashierName,
      customerNote: finalNote,
      referenceNumber: referenceNumber || (paymentMethod === 'promptpay' ? `PP-${Date.now().toString().slice(-8)}` : undefined),
    };

    // Deduct stock for all items
    setProducts((prevProducts) =>
      prevProducts.map((prod) => {
        const itemQuantitySum = rawItems
          .filter((it) => it.productId === prod.id)
          .reduce((sum, it) => sum + it.quantity, 0);
        if (itemQuantitySum > 0) {
          const newStock = Math.max(0, prod.stock - itemQuantitySum);
          return { ...prod, stock: newStock };
        }
        return prod;
      })
    );

    // Remove from held orders
    setHeldOrders((prev) => prev.filter((h) => !heldIds.includes(h.id)));

    // Save order
    setOrders((prev) => [newOrder, ...prev]);

    // Celebration & Audio
    playBeep('success');
    confetti({
      particleCount: 90,
      spread: 75,
      origin: { y: 0.6 },
    });

    // Broadcast order completed to Customer Display
    broadcastCustomerDisplay({
      type: 'ORDER_COMPLETED',
      payload: {
        order: newOrder,
      },
    });

    showToast(`ชำระเงินรวมสำเร็จ ${targets.length} บิล (${orderNumber})`, 'success');

    // Auto open receipt
    setSelectedOrderForReceipt(newOrder);

    return newOrder;
  };

  // Payment Processing & Checkout
  const processPayment = ({
    paymentMethod,
    cashReceived,
    referenceNumber,
    customerNote,
  }: {
    paymentMethod: 'cash' | 'promptpay' | 'card' | 'transfer';
    cashReceived?: number;
    referenceNumber?: string;
    customerNote?: string;
  }): Order => {
    const orderSeq = String(orders.length + 1).padStart(4, '0');
    const datePrefix = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const orderNumber = `INV-${datePrefix}-${orderSeq}`;

    const orderItems = cart.map((item) => ({
      productId: item.product.id,
      name: item.product.name,
      sku: item.product.sku,
      price: item.product.price,
      cost: item.product.cost,
      quantity: item.quantity,
      total: item.product.price * item.quantity,
      note: item.note,
    }));

    const change = cashReceived ? Math.max(0, cashReceived - cartTotals.total) : 0;

    const newOrder: Order = {
      id: 'ord-' + Date.now(),
      orderNumber,
      items: orderItems,
      subtotal: cartTotals.subtotal,
      discount: cartTotals.discountAmount,
      discountType,
      vatRate: settings.vatRate,
      vatAmount: cartTotals.vatAmount,
      isVatIncluded: settings.vatType === 'included',
      total: cartTotals.total,
      paymentMethod,
      cashReceived,
      change,
      status: 'completed',
      createdAt: new Date().toISOString(),
      cashierName: settings.cashierName,
      customerNote,
      referenceNumber: referenceNumber || (paymentMethod === 'promptpay' ? `PP-${Date.now().toString().slice(-8)}` : undefined),
    };

    // Deduct stock for each product
    setProducts((prevProducts) =>
      prevProducts.map((prod) => {
        const cartMatch = cart.find((item) => item.product.id === prod.id);
        if (cartMatch) {
          const newStock = Math.max(0, prod.stock - cartMatch.quantity);
          return { ...prod, stock: newStock };
        }
        return prod;
      })
    );

    // Save order
    setOrders((prev) => [newOrder, ...prev]);

    // Clear cart
    clearCart();

    // Celebration & Audio
    playBeep('success');
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });

    // Broadcast order completed to Customer Display
    broadcastCustomerDisplay({
      type: 'ORDER_COMPLETED',
      payload: {
        order: newOrder,
      },
    });

    showToast(`ชำระเงินสำเร็จ บิลเลขที่ ${orderNumber}`, 'success');

    // Auto open receipt if enabled
    setSelectedOrderForReceipt(newOrder);

    return newOrder;
  };

  const refundOrder = (orderId: string, reason?: string) => {
    const targetOrder = orders.find((o) => o.id === orderId);
    if (!targetOrder || targetOrder.status === 'refunded') return;

    // Restore stock
    setProducts((prevProducts) =>
      prevProducts.map((prod) => {
        const itemMatch = targetOrder.items.find((item) => item.productId === prod.id);
        if (itemMatch) {
          return { ...prod, stock: prod.stock + itemMatch.quantity };
        }
        return prod;
      })
    );

    // Update order status
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              status: 'refunded',
              customerNote: reason ? `[คืนเงิน] ${reason}` : o.customerNote,
            }
          : o
      )
    );

    playBeep('alert');
    showToast(`คืนเงินบิล ${targetOrder.orderNumber} และคืนสต็อกสำเร็จ`, 'info');
  };

  const cancelOrder = (orderId: string) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: 'cancelled' } : o))
    );
    showToast('ยกเลิกบิลเรียบร้อยแล้ว', 'info');
  };

  // Stock In / Out / Adjust
  const stockIn = (productId: string, quantity: number, supplierName: string, reason: string, cost?: number) => {
    const product = products.find((p) => p.id === productId);
    if (!product) return;

    const beforeStock = product.stock;
    const afterStock = beforeStock + quantity;

    const movement: StockMovement = {
      id: 'sm-' + Date.now(),
      referenceNo: `RCV-${Date.now().toString().slice(-8)}`,
      productId,
      productName: product.name,
      productSku: product.sku,
      type: 'in',
      quantity,
      beforeStock,
      afterStock,
      reason,
      supplierName,
      costPerUnit: cost || product.cost,
      performedBy: settings.cashierName,
      createdAt: new Date().toISOString(),
    };

    setStockMovements((prev) => [movement, ...prev]);
    setProducts((prev) =>
      prev.map((p) =>
        p.id === productId
          ? { ...p, stock: afterStock, cost: cost !== undefined ? cost : p.cost }
          : p
      )
    );

    playBeep('success');
    showToast(`รับสินค้า "${product.name}" เข้าสต็อก +${quantity} ${product.unit}`, 'success');
  };

  const stockOut = (productId: string, quantity: number, reason: string) => {
    const product = products.find((p) => p.id === productId);
    if (!product) return;

    const beforeStock = product.stock;
    const afterStock = Math.max(0, beforeStock - quantity);

    const movement: StockMovement = {
      id: 'sm-' + Date.now(),
      referenceNo: `OUT-${Date.now().toString().slice(-8)}`,
      productId,
      productName: product.name,
      productSku: product.sku,
      type: 'out',
      quantity,
      beforeStock,
      afterStock,
      reason,
      performedBy: settings.cashierName,
      createdAt: new Date().toISOString(),
    };

    setStockMovements((prev) => [movement, ...prev]);
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, stock: afterStock } : p))
    );

    playBeep('alert');
    showToast(`จ่ายสินค้าออก -${quantity} ${product.unit}`, 'info');
  };

  const adjustStock = (productId: string, newStock: number, reason: string) => {
    const product = products.find((p) => p.id === productId);
    if (!product) return;

    const beforeStock = product.stock;
    const diff = newStock - beforeStock;

    const movement: StockMovement = {
      id: 'sm-' + Date.now(),
      referenceNo: `ADJ-${Date.now().toString().slice(-8)}`,
      productId,
      productName: product.name,
      productSku: product.sku,
      type: 'adjust',
      quantity: diff,
      beforeStock,
      afterStock: newStock,
      reason,
      performedBy: settings.cashierName,
      createdAt: new Date().toISOString(),
    };

    setStockMovements((prev) => [movement, ...prev]);
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, stock: newStock } : p))
    );

    playBeep('info');
    showToast(`ปรับยอดสต็อก "${product.name}" เป็น ${newStock} ${product.unit}`, 'info');
  };

  // Batch Multi-Product Stock Operation (รับเข้า / เบิกออก / ปรับปรุงสต็อก แบบหลายรายการ)
  const batchStockOperation = ({
    type,
    items,
    supplierName,
    reason,
    referenceNo,
  }: {
    type: 'in' | 'out' | 'adjust';
    items: Array<{
      productId: string;
      quantity: number;
      cost?: number;
      note?: string;
    }>;
    supplierName?: string;
    reason: string;
    referenceNo?: string;
  }) => {
    if (!items || items.length === 0) {
      showToast('กรุณาเลือกรายการสินค้าอย่างน้อย 1 รายการ', 'warning');
      return;
    }

    const batchId = 'batch-' + Date.now();
    const docRef = referenceNo || `${type === 'in' ? 'RCV' : type === 'out' ? 'OUT' : 'ADJ'}-${Date.now().toString().slice(-8)}`;
    const nowIso = new Date().toISOString();

    const newMovements: StockMovement[] = [];
    const updatedProductsMap = new Map<string, { stock: number; cost?: number }>();

    items.forEach((item, idx) => {
      const product = products.find((p) => p.id === item.productId);
      if (!product) return;

      const beforeStock = updatedProductsMap.has(product.id)
        ? updatedProductsMap.get(product.id)!.stock
        : product.stock;

      let afterStock = beforeStock;
      let qtyDelta = item.quantity;

      if (type === 'in') {
        afterStock = beforeStock + item.quantity;
      } else if (type === 'out') {
        afterStock = Math.max(0, beforeStock - item.quantity);
      } else if (type === 'adjust') {
        afterStock = item.quantity;
        qtyDelta = item.quantity - beforeStock;
      }

      updatedProductsMap.set(product.id, {
        stock: afterStock,
        cost: item.cost !== undefined ? item.cost : product.cost,
      });

      newMovements.push({
        id: `sm-${Date.now()}-${idx}`,
        referenceNo: docRef,
        batchId,
        productId: product.id,
        productName: product.name,
        productSku: product.sku,
        type,
        quantity: qtyDelta,
        beforeStock,
        afterStock,
        reason: item.note ? `${reason} (${item.note})` : reason,
        supplierName: supplierName || undefined,
        costPerUnit: item.cost !== undefined ? item.cost : product.cost,
        performedBy: settings.cashierName,
        createdAt: nowIso,
        note: item.note,
      });
    });

    // Update global stock movements
    setStockMovements((prev) => [...newMovements, ...prev]);

    // Update products stock & cost
    setProducts((prev) =>
      prev.map((p) => {
        if (updatedProductsMap.has(p.id)) {
          const update = updatedProductsMap.get(p.id)!;
          return {
            ...p,
            stock: update.stock,
            cost: update.cost !== undefined ? update.cost : p.cost,
          };
        }
        return p;
      })
    );

    const typeLabel = type === 'in' ? 'รับเข้า' : type === 'out' ? 'เบิกจ่ายออก' : 'ปรับยอด';
    playBeep('success');
    showToast(`บันทึกเอกสาร ${docRef} (${typeLabel} ${items.length} รายการ) สำเร็จ`, 'success');
  };

  // Suppliers CRUD
  const addSupplier = (supplierData: Omit<Supplier, 'id' | 'productsCount'>) => {
    const newSupplier: Supplier = {
      ...supplierData,
      id: 'sup-' + Date.now(),
      productsCount: 0,
    };
    setSuppliers((prev) => [newSupplier, ...prev]);
    showToast(`เพิ่มซัพพลายเออร์ "${newSupplier.name}" สำเร็จ`, 'success');
  };

  const updateSupplier = (id: string, updated: Partial<Supplier>) => {
    setSuppliers((prev) =>
      prev.map((s) => (s.id === id ? { ...s, ...updated } : s))
    );
    showToast('อัปเดตข้อมูลซัพพลายเออร์สำเร็จ', 'success');
  };

  const deleteSupplier = (id: string) => {
    setSuppliers((prev) => prev.filter((s) => s.id !== id));
    showToast('ลบซัพพลายเออร์แล้ว', 'info');
  };

  return (
    <PosContext.Provider
      value={{
        activeTab,
        setActiveTab,
        theme,
        setTheme,
        toggleTheme,
        settings,
        updateSettings,
        categories,
        addCategory,
        updateCategory,
        deleteCategory,
        units,
        addUnit,
        updateUnit,
        deleteUnit,
        noteOptions,
        addNoteOption,
        updateNoteOption,
        deleteNoteOption,
        broadcastCustomerDisplay,
        openCustomerDisplayWindow,
        products,
        addProduct,
        updateProduct,
        deleteProduct,
        cart,
        addToCart,
        updateCartQuantity,
        updateCartItemNote,
        removeFromCart,
        clearCart,
        discount,
        discountType,
        setDiscount,
        cartTotals,
        heldOrders,
        holdCurrentCart,
        resumeHeldOrder,
        deleteHeldOrder,
        batchDeleteHeldOrders,
        mergeHeldOrdersIntoCart,
        processBatchHeldPayment,
        orders,
        processPayment,
        refundOrder,
        cancelOrder,
        stockMovements,
        stockIn,
        stockOut,
        adjustStock,
        batchStockOperation,
        suppliers,
        addSupplier,
        updateSupplier,
        deleteSupplier,
        selectedOrderForReceipt,
        setSelectedOrderForReceipt,
        playBeep,
        toast,
        showToast,
      }}
    >
      {children}
    </PosContext.Provider>
  );
};

export const usePos = () => {
  const context = useContext(PosContext);
  if (!context) {
    throw new Error('usePos must be used within a PosProvider');
  }
  return context;
};
