export interface Category {
  id: string;
  name: string;
  icon?: string;
  color?: string;
}

export interface UnitItem {
  id: string;
  name: string;
}

export interface NoteOption {
  id: string;
  name: string;
  category?: string; // e.g. 'ระดับความหวาน', 'ตัวเลือกเครื่องดื่ม', 'ตัวเลือกอาหาร', 'ตัวเลือกทั่วไป'
  priceAdjustment?: number; // e.g. 0, 10, 15
}

export interface Product {
  id: string;
  sku: string;
  barcode?: string;
  name: string;
  category: string;
  price: number;
  cost: number;
  stock: number;
  minStockAlert: number;
  image: string;
  description?: string;
  unit: string;
  status: 'active' | 'inactive';
  noteOptionIds?: string[]; // IDs of bound NoteOptions
}

export interface CartItem {
  product: Product;
  quantity: number;
  note?: string;
  discount?: number; // percentage or fixed
}

export interface OrderItem {
  productId: string;
  name: string;
  sku: string;
  price: number;
  cost: number;
  quantity: number;
  total: number;
  note?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  discountType: 'amount' | 'percent';
  vatAmount: number;
  vatRate: number;
  isVatIncluded: boolean;
  total: number;
  paymentMethod: 'cash' | 'promptpay' | 'card' | 'transfer';
  cashReceived?: number;
  change?: number;
  status: 'completed' | 'refunded' | 'cancelled';
  createdAt: string;
  cashierName: string;
  customerNote?: string;
  referenceNumber?: string;
}

export interface HeldOrder {
  id: string;
  heldNumber: string;
  customerName?: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  discountType: 'amount' | 'percent';
  note?: string;
  createdAt: string;
  total: number;
}

export interface StockMovement {
  id: string;
  referenceNo: string;
  batchId?: string;
  productId: string;
  productName: string;
  productSku: string;
  type: 'in' | 'out' | 'adjust'; // รับเข้า | จ่ายออก | ปรับปรุง
  quantity: number;
  beforeStock: number;
  afterStock: number;
  reason: string;
  supplierName?: string;
  costPerUnit?: number;
  performedBy: string;
  createdAt: string;
  note?: string;
}

export interface BatchStockOperationItem {
  productId: string;
  quantity: number; // for in/out: quantity, for adjust: target new stock level
  cost?: number;
  note?: string;
}

export interface StockBatchSummary {
  referenceNo: string;
  type: 'in' | 'out' | 'adjust';
  itemsCount: number;
  totalQuantity: number;
  totalCostValue: number;
  reason: string;
  supplierName?: string;
  performedBy: string;
  createdAt: string;
  items: StockMovement[];
}

export interface Supplier {
  id: string;
  code: string;
  name: string;
  contactPerson: string;
  phone: string;
  email: string;
  address: string;
  productsCount: number;
}

export interface StoreSettings {
  storeName: string;
  branchName: string;
  taxId: string;
  phone: string;
  email: string;
  address: string;
  promptPayId: string;
  currencySymbol: string;
  decimalPlaces: number; // 0, 2, 3
  vatRate: number; // 7
  vatType: 'included' | 'excluded'; // รวมในราคาสินค้า หรือ แยกนอก
  receiptFooterMessage: string;
  printerType: 'thermal_80mm' | 'thermal_58mm';
  autoPrintReceipt: boolean;
  enableSoundEffects: boolean;
  cashierName: string;
  theme?: 'light' | 'dark';
}
